package com.batch91.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.batch91.jwt.JwtService;
import com.batch91.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.batch91.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationCotroller {
	
	@Autowired
	JwtService jwtService;
	
	@PostMapping("/login")
	public ResponseEntity<?> authenticateUser(@RequestBody User user){
		if("bhagyashri".equals(user.getUsername()) && "Bnpatil".equals(user.getPassword())) {
			String token = jwtService.generateToken(user.getUsername());
			System.out.println(token);
			return new ResponseEntity<>(token,HttpStatus.OK);
		}
			
		return new ResponseEntity<>("Authentication Fail",HttpStatus.UNAUTHORIZED);
		
	}
	
	
	
	
// Use Registration Details
	
	

	
}
