/**
 * 
 */
package com.batch91.jwt;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * @author BHAGYASHRI
 *
 */
@Component
public class JwtService {
	
	
	public String generateToken(String userName) {
		Map<String,Object> claims=new HashMap<>();
			return Jwts.builder()
					.setClaims(claims)
					.setSubject(userName)
					.setIssuedAt(new Date(System.currentTimeMillis()))
					.setExpiration(new Date(System.currentTimeMillis() + 1*60*60*1000))
					.signWith(SignatureAlgorithm.HS256, "Bhagya")
					.compact();
		}

}
