package com.batch91;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudNoSqlDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudNoSqlDbApplication.class, args);
	}

}
