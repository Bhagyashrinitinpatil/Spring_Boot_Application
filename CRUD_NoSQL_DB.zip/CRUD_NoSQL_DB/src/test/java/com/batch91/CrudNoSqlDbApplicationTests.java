package com.batch91;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudNoSqlDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
