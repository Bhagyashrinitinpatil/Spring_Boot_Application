package com.batch91.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.batch91.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.batch91.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationCotroller {
	
	@PostMapping("/login")
	public ResponseEntity<?> authenticateUser(@RequestBody User user){
		if("bhagyashri".equals(user.getUsername()) && "Bnpatil".equals(user.getPassword())) {
			String token = generateToken(user.getUsername());
			System.out.println(token);
			return new ResponseEntity<>(token,HttpStatus.OK);
		}
			
		return new ResponseEntity<>("Authentication Fail",HttpStatus.OK);
		
	}
	
	
	public String generateToken(String userName) {
	Map<String,Object> claims=new HashMap<>();
		return Jwts.builder().setClaims(claims).setSubject(userName).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 1*60*60*1000)).signWith(SignatureAlgorithm.HS256, "BhagyashriNitinPatil123").compact();
	}
	
// Use Registration Details
	
	

	
}
